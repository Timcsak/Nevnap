const express = require('express');
const fs = require('fs');
const path = require('path');

const bodyParser = require('body-parser');

const app = express();
app.use(bodyParser.urlencoded({extended: true}));
app.use(bodyParser.json());

let nevnapok = JSON.parse(fs.readFileSync('nevnap.json', 'utf8'));

// összes névnap lekérdezése
app.get('/nevnapok', (req,res) => {
    res.status(200).json(nevnapok);
});

var picked = nevnapok.filter(function(value){ return value.nev1=="Dániel";})
console.log(picked);

// index.html beállítása kezdőlapként
app.get('/', (req,res) => {
    res.sendFile(path.join(__dirname, 'index.html'));
});

app.listen(3000, () => {
    console.log('Fut a szerver ezen a címen: http://localhost:3000');

});